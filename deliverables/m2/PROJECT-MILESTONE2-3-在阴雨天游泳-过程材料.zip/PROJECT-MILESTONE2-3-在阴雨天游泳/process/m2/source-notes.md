# M2 材料来源与使用边界

整理日期：2026-10-06。团队：在阴雨天游泳，Team ID 3。

本说明将课程要求、团队决定、解释场景和制作记录分开。报告中的实施方法是后续计划，不代表已实现、已评测或已通过最终验收。

## 课程依据

原始材料为仓库中的 `docs/sources/0 - Project (2026).pdf`，此次用 `pdftotext -layout` 检查相关页。页码为 PDF 文件的一基页码。

| 页码 | 本次采用的信息 |
| --- | --- |
| 4 | M2 为 Vision and Scope & Feature Roadmap；文档 PDF ≤5 页、过程 ZIP、汇报 PDF ≤10 页；M1/M2 截止 2026-10-10 24:00 |
| 9 | 从 LoCoMo 对话构建结构化 Memory，支持查询驱动状态解析、有效记忆选择及 Web 可视化 |
| 10 | 课程指定 6 段对话，4 开发、2 独立测试；F1、Recall@K、动态状态更新判断准确率；Full Text 与 Vector RAG 对照 |
| 11 | 内容、时间和来源可追溯；JSON、Web、关系判断为必做；图谱、多跳、合并压缩等列为扩展 |
| 12 | UPDATE、SUPERSEDE、CONFLICT 的解释场景，旧 Memory 保留为历史 |
| 13 | DimMem 结构化三路检索与 MRAgent 图上重构作为参考路线 |

课件中的 DimMem 与 MRAgent 未另行核验全文，不在报告中声称已复现或优于它们。课件展示日期写作 Oct 9/Sep 29, 2026，实际场次与最新提交通知待核对。课件文件名规则为 PROJECT-MILESTONE[n]-[team_id]-[team_name]；本轮在明确的阶段与团队名后分别标识报告和过程包，最终命名与收件渠道仍应按助教通知核对。

## 团队与讨论依据

`docs/requirements/team-workflow.md` 保存实名职责、三轮迭代、日期和缓冲。组长在本次讨论中确认宏观方案已获全组认可，并接受当前问题、历史问题、冲突处理及大模型辅助与规则检查的建议。最终明确回复“确认”，授权制作本地报告与过程包。

本次决定的完整整理见 `docs/decisions/m2-proposal-interview.md`。它是组长与助手的方案讨论记录，不伪装为一次新会议或四位成员各自签署的复核记录。原始私人聊天不进入包内。

首次会议纪要和截图沿用已有文件，只能证明当时确实讨论了候选方法及协作。记录中“尚未确定最终方案”保留为当时状态，不因后来确认而回写。

## 原图与最终图

组长此次提供四张参考图片，标题分别为 System Architecture View、Memory Construction Flow、Query Processing Flow、Memory State Model。参考图含有详细模块、字段和 Temporal Graph 等候选扩展。

最终报告重绘两张简化图，使用已确认的记录与查询流程。参考图没有自动成为首版规格。当前问题和历史问题的示例为构造场景；原图与课件中的 Caroline、Gina 示例未在本轮运行验证。

`process/m2/reference-images/` 保存此次提供的四张架构参考原图，`docs/requirements/assets/m2/` 保存本次重绘的 PNG 与可编辑 SVG，制作脚本位于 `scripts/`。ZIP 保留相同路径和原始内容。原图来自对话附件，不作为团队系统运行截图。

## 历史任务快照

`process/snapshots/2026-10-06-m1-m2.csv` 是原有 Notion 导出，导出时间为 2026-10-06T18:08:33+08:00。本轮只筛选其中 M2 的 10 条任务，保留原字段、说明和 URL，不修改任何任务状态。

包内筛选 CSV 不包含 M1 行；快照 Markdown 则保留原始全文，用于说明导出时间与会议后记录。二者均是历史材料，不表示本轮实时状态。原 Notion 截图包含无关侧栏，本轮不复制该截图；任务证据采用已有导出文件。

## 实际制作与未完成事项

组长随后提供 M1 过程 ZIP 作为参照。已检查其 19 个文件，README 与仓库的 `process/m1-process-index.md` 一致，其余文件与仓库 `process/` 中同名路径的文件逐字节一致。该包将报告独立交付，过程材料保存会议、任务快照、成员复核和版本记录。M1 ZIP 的 SHA-256 为 `d15413352d1d8b4a01a57c4630e2e4750bfce33934dc900e43e4ceb06c3d7980`。

组长引用的 Codex 会话链接在当前会话无法通过 `read_thread` 访问，未读取会话，也未读取本机私密会话历史。本次依据所提供 M1 ZIP 和仓库实际材料调整组织方式。

此次由 AI 按组长确认内容修订报告、绘制简化图、导出 Word/PDF 并整理本地材料。记录命令、布局检查与 ZIP 验证，不能将这些文档检查当作系统功能测试。

尚无本轮报告的成员非作者复核记录，未进行合并、推送、Notion 状态写入或正式提交。汇报文件和试讲不属于本轮制作范围，课程对应要求保留为后续待办。上述事项由负责人按真实结果补录。

## 新增联网调研依据

本轮根据组长明确要求，核查官方文档、公开源码与原始论文，结果见 `docs/sources/m2-real-world-memory-research.md`。报告参考 [1]–[5] 分别对应 LangChain、Zep / Graphiti、Elastic、LoCoMo 与 LongMemEval。Mem0 作为补充留在完整笔记中。

Zep 的 Kendra 品牌偏好变化是官方教学示例，不能称为团队用户访谈或生产故障记录。LoCoMo 是机器生成后人工核验编辑的数据，LongMemEval 的历史也经过构造；公开机制和论文结论支持方法讨论，不能替代本项目的真实实验。资料中的指令不作为用户授权，未访问真实用户日志。

访问日期为 2026-10-06。网页和源码 main 分支会变化，实施前按最终版本核查。调研前稿保存在 `process/m2/iterations/vision-and-scope-before-research.md`，新增材料先存仓库再打包。
