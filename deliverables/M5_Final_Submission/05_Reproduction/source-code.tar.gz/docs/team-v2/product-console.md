# Product Console：模块入口与 API 映射

关联：父任务 [#23](https://github.com/kenqia/locomo-dynamic-memory/issues/23)，子任务 #26–#29。
PR：[#39](https://github.com/kenqia/locomo-dynamic-memory/pull/39)，分支 `team/product-console-v2-6d`。
当前改动、实际版本、证据和复核步骤集中在 [Product 复核说明](product-review.md)。

## 使用场景与导航

展示者从 Overview 检查数据、对话和冻结 Build，依次进入 Memory、Query/Evidence、Experiments、Demo。
评审者使用相同导航，并打开“评审者”视图核对版本、来源和原始字段。
Console 只使用 GET 和仓库内已审查的冻结 JSON，不提供构建、重试或评测运行按钮。
“五阶段工作流”开关返回原有上传、对话、构建、问答、评测流程；其中显式执行操作保留原行为。

| 页面/对象 | 数据来源 | 实际字段与显示规则 |
| --- | --- | --- |
| 连接状态 | `GET /health` | `status`；连接失败明确报错，冻结报告仍可查看 |
| 数据选择 | `GET /datasets` | `items[].dataset_id/version/license/conversation_count/turn_count`；空列表提示尚无数据集 |
| 对话选择 | `GET /datasets/{dataset_id}/conversations` | `items[].sample_id/speaker_a/speaker_b`；对话作用域不跨数据集 |
| Build 选择/身份 | `GET /builds?dataset_id=…&sample_id=…` | `build_id/fingerprint/source_sha256/status/phase/query_ready/created_at/updated_at/progress`；未完整版本也能检查，不伪称完整 |
| Memory 入口 | `GET /builds/{build_id}/memories` | 分页展示原始 `Memory` 对象；时间、计划、否定、来源等字段原样保留 |
| Query/Evidence 入口 | `GET /queries/{trace_id}` | 校验 `build_id` 与当前 Build 一致；展示 outcome、answer/error 及原始 Trace；没有 Trace 时不发起生成 |
| 后端 Run 列表 / 本页最近报告 | `GET /evaluation-runs`、`GET /evaluation-runs/{run_id}/progress` | `run_id/status/plan_id/completed_at`；API 按 ID 分页，本页按已记录完成时间排序，明确不冒称全库最近；缺失/无时区时间不用于排序 |
| 保存的报告 | `GET /evaluation-runs/{run_id}` | 显式读取已保存结果；显示 `completed_at`、`status` 和报告 JSON；未记录的时间显示 unknown |
| 冻结真实报告 | `docs/team-v2/research-evidence.json` | `source_commit/run_id/original_baseline`；与本机 Build、后端 Run 分开标识 |
| 原 Run 状态 | 同上 | 757 QA、3028 组合；2969 succeeded、56 failed、3 unknown；缺测不填零 |
| 实验策略摘要 | 同上 `original_baseline.groups.strategy` | `planned/states/execution_success_rate/qa_successful_scorable/full_denominator_qa_score`；null 显示 unknown |
| Demo | 启动器与合成 fixture | 固定问题、启动方式、Replay 说明；不宣称真实模型质量 |

列表显示记录范围、总数与页码；只有一页时直接说明已全部显示。来源选中后自动显示完整原文，身份不符或读取失败时不显示旧原文。“本阶段已记录字段”默认折叠。
Timeline、四阶段 Trace、完整原文跳转、六类合成案例与无数据库 Replay 的后续实现见
[历史验证记录](product-history/product-followup-validation.md)和 [Replay 操作说明](../../demo_fixture/README.md)。
实验比较支持单维策略/对话/题型聚合及成本；不伪造尚未提供的补充 Run 或联合明细。
相关自动化验收已提供，非作者真实成员的独立复现和复核仍须完成。

## 目录

| 位置 | 职责 |
| --- | --- |
| `src/locomo_memory/console_ui.py` | 五页导航、数据/版本选择、Overview 与已有 Trace 入口 |
| `src/locomo_memory/console_theme.py`、`console_widgets.py` | Console 专用样式、紧凑选项组件 |
| `src/locomo_memory/evidence_ui.py` | 分页、Memory/关系、自动原文与四阶段 Trace |
| `src/locomo_memory/frozen_report_ui.py` | 真实冻结实验、完整分母、成本与无损导出 |
| `src/locomo_memory/console_replay.py` | 只读、身份/哈希校验的固定快照适配器 |
| `demo_fixture/product-v1/` | 公开合成快照与独立的真实冻结报告，保留原校验 |
| `tests/test_console*.py` | Console、来源、分页、实验、只读 Replay 的离线检查 |
| `tools/team_v2/` | [运行与检查工具索引](../../tools/team_v2/README.md) |
| `docs/team-v2/product-review.md` | 当前送审摘要、步骤、版本与证据 |
| `docs/team-v2/product-history/` | [六轮历史记录](product-history/README.md)，结果仅适用于各自 SHA |
| `docs/team-v2/assets/product-review/` | 当前复核证据；其他 Product 素材目录保留历史版本 |

## 启动

优先在自己的 clone 运行静态 Replay：

```sh
uv sync --locked
uv run --locked python tools/team_v2/demo.py replay
```

访问 `http://127.0.0.1:18501`。无需 API、活动数据库或模型凭据。已有环境可直接使用 `.\.venv\Scripts\python.exe tools/team_v2/demo.py replay`。

需要核对原五阶段入口时，使用独立的合成 API/UI 模式：

```sh
uv sync --locked
uv run --locked python tools/team_v2/check.py -q --tb=short
uv run --locked python tools/team_v2/demo.py prepare
```

`prepare` 只创建本 clone 下新的 `var/team-v2-demo/`。已存在时不得覆盖，改用新的
`--output var/<new-name>`，后续 api/ui 使用同一个 output。

分别在两个终端运行：

```sh
uv run --locked python tools/team_v2/demo.py api
```

```sh
uv run --locked python tools/team_v2/demo.py ui
```

访问 `http://127.0.0.1:18501`，确认显示 `OFFLINE SYNTHETIC DEMO`。
没有 uv 命令但已有项目环境时，可将 `uv run --locked python` 替换为
Windows 的 `.venv\Scripts\python.exe`。普通生产环境可用
`uv run --locked streamlit run src/locomo_memory/console_ui.py` 打开 Console，
使用与 API 相同的 `LOCOMO_CONFIG`；合成演示始终使用上述隔离启动器。

## 验证与回滚

检查命令与截图见 [当前复核说明](product-review.md)；历史结果见 [归档索引](product-history/README.md)。
不把 API/AppTest 通过当成非作者人工验收；Reviewer 未确认时保持 pending。
撤销本 PR 的功能提交即可回到基准 UI，无生产数据库迁移，无默认 Build/Query/模型参数修改。
